<?php

class DefaultAliasController extends Controller
{
    
    /**
     * Set of access rules for this controller.
     * 
     * @return array 
     */
    public function accessRules()
    {
        return array(
            array('allow',
                'users' => array('*'),
            ),
        );
    }

    public function actionIndex()
    {
        $this->render('index');
    }

    public function actionForward()
    {
        $parent = $this->module->parentModule;
        if ($parent === null)
        {
            $node = Yii::app()->menuManager->currentNode;
            if(     ($aliasLinkModel = $node->getDataRecord()) !== null
                    && ($originalNodeModel = StructureModel::model()->findByAttributes(array('id'=>$aliasLinkModel->nodeId))) !== null
            )
            {
                $_GET['aliasLink'] = $originalNodeModel->alias;
                $title = $node->pageTitle;

                Yii::app()->breadcrumbs->readOnly = true;
                Yii::app()->menuManager->currentNode = $originalNodeModel;

                $route = '/'.$originalNodeModel->moduleId . '/'
                        . ($originalNodeModel->actionId === ''
                            ? 'default/index'
                            : str_replace('.', '/', $originalNodeModel->actionId ));
                
                $originalNodeModel->pageTitle = $title;
                
                $this->forward($route);
            }
        }
        
        throw new CHttpException(404, 'Page not found.');
    }
    
    public function ensureDeletable($event)
    {
        if ($event->sender->model->getRelated('owner') instanceof CActiveRecord)
        {
            $event->sender->noDelete();
        }
    }
}