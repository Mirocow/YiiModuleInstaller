<?php

$this->breadcrumbs = array(
    'Modules' => array('/admin/module'),
    'Alias Link Module',
);

$this->pageTitle = 'Alias links management';
$this->widget('wmdl.components.datagrid.CDataGrid', array(
    'modelClass'=>'AliasLinkModel',
    'onItemCreated'=>array($this, 'ensureDeletable'),
));
