<?php

/**
 * This is the model class for table "AliasLink".
 *
 * The followings are the available columns in table 'AliasLink':
 * @property string $id
 * @property string $nodeId
 * @property string $title
 * @property boolean $useTargetUrl
 * @property StructureModel $node
 * @property StructureModel $owner
 */
class AliasLinkModel extends CActiveRecord implements INodeDataModel
{

    /**
     * Returns the static model of the specified AR class.
     * @return AliasLinkModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'AliasLink';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('nodeId', 'required'),
            array('nodeId', 'length', 'max' => 10),
            array('nodeId', 'numerical', 'min' => 0),
            array('title', 'length', 'max' => 255),
            array('useTargetUrl', 'default', 'value' => 1),
            array('useTargetUrl', 'filter', 'filter' => 'intval'),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'node' => array(self::BELONGS_TO, 'StructureModel', 'nodeId'),
            'owner' => array(
                self::HAS_ONE, 'StructureModel', 'dataPk', 
                'on' => 'owner.dataClass = :class',
                'params' => array(
                    ':class' => get_class(),
                ),
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'nodeId' => 'Node',
            'title' => 'Title',
        );
    }

    public function fields()
    {

        $currentNode = Yii::app()->menuManager->getCurrentNode();

        return array(
            array('nodeId', 'listBox', Yii::app()->menuManager->getListData(),
                array(
                    'size' => 10, 
                    'options' => array(
                        array('disabled' => true),
                        $currentNode['id'] => array('disabled' => true),
                ))),
            array('useTargetUrl', 'checkbox'),
        );
    }

    public function getSiteNode()
    {
        return $this->getRelated('owner');
    }

}