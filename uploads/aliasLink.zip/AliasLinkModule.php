<?php

/**
 * AliasLinkModule class file.
 *
 * @author Sergey Malyshev <malyshev.php@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */

/**
 * AliasLinkModule represents an application module.
 *
 * Alias Link creates a Link to an existing Site Node.
 * It will take the parameter setup of the target Menu Item.
 *
 * @author Sergey Malyshev <malyshev.php@gmail.com>
 * @version $Id: AliasLinkModule.php 706 2011-09-30 15:47:29Z Kucherenko $
 * @package modules.aliasLink
 * @since 1.0.3
 */

class AliasLinkModule extends CApplicableWebModule
{
    public $author = 'Sergey Malyshev';

    public $authorEmail = 'malyshev.php@gmail.com';

    public $version = '1.0.0';

    public static $route;

    protected $releaseDate = '2011-02-16';
    
    public $defaultController = 'defaultAlias';
    
    public function getName()
    {
        return 'Alias Link';
    }

    public function getDescription()
    {
        return 'Creates a copy of another menu item.';
    }

    public function init()
    {
        $this->setImport(array(
                'aliasLink.models.*',
                'aliasLink.components.*',
        ));
    }

    public function setup($modelClass = 'AliasLinkModel')
    {
        $node = Yii::app()->controller->getNodeModel();
        
        if ($node->dataRecord instanceof $modelClass)
        {
            $model = $node->dataRecord;
            $model->scenario = 'updateNode';
        }
        else
        {
            $model = new $modelClass;
            $model->scenario = 'insertNode';
        }
        
        return parent::setup($model);
    }
    
    public function beforeSetup(CEvent $event)
    {
        if (empty($event->sender->configModel->title))
            $event->sender->configModel->title = $event->sender->nodeModel->caption;
        
        $event->sender->nodeModel->actionId = $this->defaultController.'.forward'; 
        
        return parent::beforeSetup($event);
    }

}