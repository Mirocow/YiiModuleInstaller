<?php
return array(
	'title' => 'Alias Module',
	'description' => 'This module allows you to add and manage articles organized into categories.',
);