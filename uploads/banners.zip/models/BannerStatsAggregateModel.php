<?php

/**
 * BannerStatsAggregateModel represents an ...
 *
 * Description of BannerStatsAggregateModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $date
 * @property string $impressions
 * @property string $clicks
 * @property string $ctr
 */
class BannerStatsAggregateModel extends CActiveRecord
{
    /**
     * Returns the static model of the specified AR class.
     * @return BannerStatsAggregateModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'BannerStatsAggregate';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('date', 'required'),
            array('impressions', 'length', 'max'=>33),
            array('clicks', 'length', 'max'=>32),
            array('ctr', 'length', 'max'=>37),
        );
    }
    
    protected function afterFind()
    {
        $this->ctr = round($this->ctr, 2);
        
        $dot = strpos($this->ctr, '.');
        
        if ($dot === false)
        {
            $this->ctr .= '.00';
        }
        else
        {
            $this->ctr = str_pad($this->ctr, $dot + 3, 0, STR_PAD_RIGHT);
        }
        
        parent::afterFind();
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'date' => 'Date',
            'impressions' => 'Impressions',
            'clicks' => 'Clicks',
            'ctr' => 'CTR',
        );
    }
}