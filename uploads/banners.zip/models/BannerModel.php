<?php


Yii::import('wmdl.components.widgetFactory.WidgetModel', true);
Yii::import('admin.widgets.NotificationWidget');

/**
 * BannerModel represents an ...
 *
 * This is the model class for table "Banner".
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $id
 * @property string $type
 * @property string $name
 * @property string $link
 * @property string $image
 * @property string $code
 * @property string $impressions
 * @property string $clicks
 * @property boolean $enabled
 * @property string $created
 * @property string $updated
 */
class BannerModel extends CActiveRecord
{
    
    const WIDGET_TYPE = 'application.widgets.banner.BannerWidget';
    
    private $_widgets;
    private static $_wl;

    public function __toString()
    {
        if ($this->name)
        {
            if ($this->type)
            {
                $details = ' (' . $this->type . ($this->enabled ? '' : ', disabled') . ')';
            }
            else if (!$this->enabled)
            {
                $details = ' (disabled)';
            }
            
            return $this->name . $details;
        }
    }
    
    /**
     * Returns the static model of the specified AR class.
     * @return BannerModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'Banner';
    }

    /**
     * Models supports 2 validation scenarios:
     * <ul>
     * <li>plain</li>
     * <li>html</li>
     * </ul>
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('type, name, enabled', 'required'),
            array('link', 'required', 'on' => 'plain'),
            array('link', 'url', 'on' => 'plain', 'defaultScheme' => 'http'),
            array('code', 'required', 'on' => 'html'),
            array('enabled', 'numerical', 'integerOnly' => true),
            array('type', 'in', 'range' => array_keys(BannerStatus::listData())),
            array('name, image', 'length', 'max' => 255),
            array('impressions, clicks', 'numerical', 'integerOnly' => true),
            array('impressions, clicks', 'length', 'max' => 11),
            array('updated, created', 'default', 'value' => '0000-00-00'),
            array('link,code', 'default', 'value' => ''),
            array('link,code', 'safe', 'on' => 'insert,update'),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
        );
    }

    /**
     * @return array model behaviors.
     */
    public function behaviors()
    {
        return array(
            'CTimestampBehavior' => array(
                'class' => 'zii.behaviors.CTimestampBehavior',
                'createAttribute' => 'created',
                'updateAttribute' => 'updated',
            ),
            'BannerStatsBehavior' => array(
                'class' => 'banners.components.BannerStatsBehavior',
            ),
            'BannerModelWidgetBehavior' => array(
                'class' => 'banners.components.BannerModelWidgetBehavior',
                'type' => 'application.widgets.banner.BannerWidget',
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'type' => 'Type',
            'name' => 'Name',
            'link' => 'Link',
            'image' => 'Image',
            'code' => 'HTML Code',
            'impressions' => 'Impressions',
            'clicks' => 'Clicks',
            'enabled' => 'Enabled',
            'created' => 'Created',
            'updated' => 'Updated',
            'widgets' => 'Widget Assignment',
        );
    }
    
    /**
     * @return array default select confition
     */
    public function defaultScope()
    {
        return array(
            'alias' => 'banner',
        );
    }
    
    /**
     * @return array named condition scopes
     */
    public function scopes()
    {
        return array(
            'enabled' => array(
                'condition' => 'banner.enabled = :enabled',
                'params' => array(':enabled' => BannerStatus::ENABLED),
            ),
            'disabled' => array(
                'condition' => 'banner.enabled = :enabled',
                'params' => array(':enabled' => BannerStatus::DISABLED),
            ),
        );
    }

    protected function beforeValidate()
    {
        if ($this->type == BannerType::LINK)
        {
            $this->scenario = 'plain';
        } 
        else if ($this->type == BannerType::HTML)
        {
            $this->scenario = 'html';
        }
        
        preg_match('/^\/(.+)/e', $this->link, $matches);
        if (isset($matches[1]))
        {
        	$this->link = Yii::app()->createAbsoluteUrl($matches[1]);
        }
        
        return parent::beforeValidate();
    }
    
    public function updateAfterShow()
    {
        $this->impressions ++;
        $this->save(false, array('impressions'));
        
        if($this->hasEventHandler('onAfterShow'))
            $this->onAfterShow(new CEvent($this));
    }
    
    public function updateAfterClick()
    {
        $this->clicks ++;
        $this->save(false, array('clicks'));
        
        if($this->hasEventHandler('onAfterClick'))
            $this->onAfterClick(new CEvent($this));
    }
    
    public function onAfterShow($event)
    {
        $this->raiseEvent('onAfterShow', $event);
    }
    
    public function onAfterClick($event)
    {
        $this->raiseEvent('onAfterClick', $event);
    }
    
    protected function afterSave()
    {
        /*if (in_array($this->scenario, array('plain', 'html')))
        {
            NotificationWidget::dispatch('The changes have been saved.', NotificationType::INFO);
        }*/
        
        parent::afterSave();
    }
    
    public function getWidgets()
    {
        if ($this->_widgets === null)
        {
            $this->populateWidgets();
        }
        
        return $this->_widgets;
    }

    private function populateWidgets()
    {
        $wl = $this->getWidgetList();
        if (is_array($wl))
        {
	        foreach ($wl as $widget)
	        {
                    $params = array_merge(array('banners' => array()), $widget->params);
	            if (in_array($this->id, $params['banners']))
	            {
	                $this->_widgets[] = $widget->primaryKey;
	            }
	        }
        }
    }
    
    public static function getWidgetList()
    {
        if (self::$_wl === null)
        {
            $wl = WidgetModel::model()->findAllByAttributes(array(
                'type' => self::WIDGET_TYPE,
            ));
            self::$_wl = array();
            
            foreach ($wl as $w)
            {
                self::$_wl[$w->primaryKey] = $w;
            }
        }
        
        return self::$_wl;
    }
    
    public function getWidgetListData()
    {
        $ld = array();
        $data = $this->getWidgetList();
        $cnt  = count($data);
        
        for ($i = 0; $i < $cnt; $i++)
        {
            $w = $data[$i];
            $ld[$w->primaryKey] = (string) $w;
        }
        
        return $ld;
    }
    
    public function reassignWidgets($pks)
    {
        $widgets = self::getWidgetList();
        $pks = array_flip(array_map('intval', $pks));
        $revoke  = array_diff_key($widgets, $pks);
        $assign  = array_intersect_key($widgets, $pks);
        
        foreach ($revoke as $w)
        {
            $params = array_merge(array('banners' => array()), $w->params);
            $key = array_search($this->id, $params['banners']);
            if (false !== $key)
            {
	            unset($params['banners'][$key]);
	            
	            $w->params = $params;
	            $w->save();
            }
        }
        
        foreach ($assign as $w)
        {
            $params = array_merge(array('banners' => array()), $w->params);
            
            if (!in_array($this->id, $params['banners']))
            {
                $params['banners'][] = $this->id;
                $w->params = $params;
                $w->save();
            }
        }
        $this->updateBannerUsage();
    }
    
    public function onUnsafeAttribute($name, $value)
    {
        if ($name == 'widgets')
        {
            $this->reassignWidgets($value);
        }
        else
        {
            parent::onUnsafeAttribute($name, $value);
        }
    }

}

class BannerType extends CEnumerable
{
    const LINK = 'Image/Link';
    const HTML = 'HTML/JavaScript';

    public static function listData()
    {
        return array(
            self::LINK => self::LINK,
            self::HTML => self::HTML,
        );
    }

}

class BannerStatus extends CEnumerable
{
    const ENABLED = 1;
    const DISABLED = 0;

    public static function listData()
    {
        return array(
            self::ENABLED => 'Yes',
            self::DISABLED => 'No',
        );
    }

}

