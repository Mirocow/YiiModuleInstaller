<?php

Yii::import('banners.models.BannerModel', true);

/**
 * BannerStatsModel represents an ...
 *
 * Description of BannerStatsModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $bannerId
 * @property string $date
 * @property integer $impressions
 * @property integer $clicks
 */
class BannerStatsModel extends CActiveRecord
{

    /**
     * Returns the static model of the specified AR class.
     * @return BannerStatsModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    public function getCTR()
    {
        return $this->clicks ? $this->impressions / $this->clicks : 0;
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'BannerStats';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('bannerId, date', 'required'),
            array('impressions, clicks', 'numerical', 'integerOnly' => true),
            array('bannerId', 'length', 'max' => 11),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'banner' => array(self::BELONGS_TO, 'BannerModel', 'bannerId'),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'bannerId' => 'Banner',
            'date' => 'Date',
            'impressions' => 'Impressions',
            'clicks' => 'Clicks',
        );
    }

    public static function clear()
    {
    	self::model()->deleteAll();
    }    
}