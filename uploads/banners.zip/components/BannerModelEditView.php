<?php

Yii::import('wmdl.components.datagrid.CDataGridEditView', true);

/**
 * BannerModelEditView represents an ...
 *
 * Description of BannerModelEditView
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannerModelEditView extends CDataGridEditView
{

    public function renderFields()
    {
        parent::renderFields();
        
        $cols = $this->getDataGrid()->getColumns();
        $required = array('impressions', 'clicks', 'created');
        $cols = array_intersect_key($cols, array_flip($required));
        $form = $this->getDataGrid()->getForm();
        $model = $this->getDataGrid()->getModel();
        
        foreach ($cols as $prop => $col)
        {
            $this->writeRow(
                    $form->labelEx($model, $prop, array(
                        'label'=>$col['caption']
                    )), CHtml::tag('td', array('class' => 'datagrid-form-inputs'), $model->$prop));
        }
        
        $bannerWidget = $this->widget('banners.widgets.WidgetCheckBoxList', array(
            'name' => 'BannerModel[widgets][]',
            'value' => $model->widgets,
        ), true);
        
        $this->writeRow(
                $form->labelEx($model, 'widgets'), 
                CHtml::tag('td', array('class' => 'datagrid-form-inputs'), $bannerWidget));
        
    }

}
