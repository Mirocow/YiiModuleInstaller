<?php

Yii::import('banners.models.BannerStatsModel', true);

/**
 * BannerStatsBehavior represents an ...
 *
 * Description of BannerStatsBehavior
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannerStatsBehavior extends CActiveRecordBehavior
{
    
    public function events()
    {
        return array(
            'onAfterShow' => 'afterShow',
            'onAfterClick' => 'afterClick',
        );
    }
    
    public function afterShow($event)
    {
        $sr = $this->getStatRecord();
        
        $sr->impressions ++;
        $sr->save();
    }
    
    public function afterClick($event)
    {
        $sr = $this->getStatRecord();
        
        $sr->clicks ++;
        $sr->save();
    }
    
    /**
     * @return BannerStatsModel
     */
    private function getStatRecord()
    {
        $pk = array(
            'bannerId' => $this->owner->primaryKey,
            'date'     => date('Y-m-d'),
        );
        
        $statRecord = BannerStatsModel::model()->findByPk($pk);
        
        if ($statRecord === null)
        {
            $statRecord = new BannerStatsModel;
            $statRecord->primaryKey = $pk;
        }
        
        return $statRecord;
    }
    
}
