<?php

/**
 * BannerWidgetModelBehavior represents an ...
 *
 * Description of BannerWidgetModelBehavior
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannerWidgetModelBehavior extends CActiveRecordBehavior
{

    public function afterSave($event)
    {
        // reset scenario required to prevent duplicate flushing of save notification
        $sc = $this->owner->scenario;
        $this->owner->scenario = '';
        $this->updateBannerUsage($this->owner->type);
        $this->owner->scenario = $sc;
    }

    public function afterDelete($event)
    {
        $this->updateBannerUsage($this->owner->type);
    }
    
    private function updateBannerUsage($type)
    {
        //$used = $this->getUsedBannerPk($type);
    	$used = Yii::app()->getModule('banners')->getUsedBannerPk($type);
        $dao = BannerModel::model();
        $transaction = $dao->getDbConnection()->beginTransaction();
        try
        {
            $condition = new CDbCriteria;
            $condition->addInCondition('id', $used);
            
            $dao->updateAll(array('used' => '0'));
            $dao->updateAll(array('used' => '1'), $condition);
        }
        catch (CDbException $dbe)
        {
            $transaction->rollback();
            return false;
        }
        
        $transaction->commit();
        
        return true;
    }
    
    /*private function getUsedBannerPk($type)
    {
        $widgets = WidgetModel::model()->findAll(array(
            'select' => 'params',
            'condition' => 'type = :type',
            'params' => array(
                ':type' => $type,
            ),
        ));
        $rels   = CHtml::listData($widgets, 'primaryKey', 'params.banners');
        $usages = array();
        
        foreach ($rels as $banners)
        {
            if (!is_array($banners)) 
            {
                continue;
            }
            
            foreach ($banners as $pk)
            {
                $usages[] = $pk;
            }
        }
        
        return array_unique($usages);
    }*/

}
