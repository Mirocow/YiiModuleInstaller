<?php

/**
 * BannerWidgetModelBehavior represents an ...
 *
 * Description of BannerWidgetModelBehavior
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannerModelWidgetBehavior extends CActiveRecordBehavior
{
	public $type;
	
    public function afterSave($event)
    {
        //return $this->updateBannerUsage();
    }

    public function afterDelete($event)
    {
        //return $this->updateBannerUsage();
    }
    
    public function updateBannerUsage()
    {
    	if (null !== $this->type)
    	{
	        $used = Yii::app()->getModule('banners')->getUsedBannerPk($this->type);
	        try
	        {
	            $condition = new CDbCriteria;
	            $condition->addInCondition('id', $used);
	            
	            $this->getOwner()->updateAll(array('used' => '0'));
	            $this->getOwner()->updateAll(array('used' => '1'), $condition);
	        }
	        catch (CDbException $dbe)
	        {
	            return false;
	        }
	        return true;
    	}
        return false;
    }
}
