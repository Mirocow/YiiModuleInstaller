
;(function($){

        
        var fnc = {
        };
        
        
        
    var BannerForm = {
        _init: function() {
            $(this.element).delegate('#BannerModel_type', 'change', $.proxy(this.typeChange, this));
            
            $(this.element).find('#BannerModel_type').trigger('change');

            this._initReadOnly($('#BannerModel_impressions,#BannerModel_clicks,#BannerModel_created'));
            this._initTypeRadio();
            this._initWidgets();
        },
        typeChange: function(event) {
            
            var el = $(event.currentTarget);
            
            if (el.val() == 'Image/Link') {
                $('#BannerModel_link').parents('tr:first').show();
                $('#BannerModel_image').parents('tr:first').show();
                $('#BannerModel_code').parents('tr:first').hide();
            } else if (el.val() == 'HTML/JavaScript') {
                $('#BannerModel_link').parents('tr:first').hide();
                $('#BannerModel_image').parents('tr:first').hide();
                $('#BannerModel_code').parents('tr:first').show();
            } else {
                $('#BannerModel_link').parents('tr:first').hide();
                $('#BannerModel_image').parents('tr:first').hide();
                $('#BannerModel_code').parents('tr:first').hide();
            }
        },
        _initReadOnly: function(fields) {
            fields.each(function(i, el){
                $(el).after('<span>' + $(el).val() + '</span>').remove();
            });
        },
        _initWidgets: function() {
            $('#BannerManager_data_grid table.data-grid').append($('#WidgetBinding').html());
        },
        _initTypeRadio: function() {
            var el = $('#BannerModel_enabled');
            
            el.after('<div class="radio-group"></div>')
            .next()
            .append('<input type="radio" name="' + el.attr('name') + '" id="' + el.attr('id') + '_1" value="1" />')
            .append('<label for="' + el.attr('id') + '_1">Yes</label>')
            .append('<input type="radio" name="' + el.attr('name') + '" id="' + el.attr('id') + '_0" value="0" />')
            .append('<label for="' + el.attr('id') + '_0">No</label>');

            var value = el.is(':checked');
            if (value) {
                $('#' + el.attr('id') + '_1').attr('checked', true);
            } else {
                $('#' + el.attr('id') + '_0').attr('checked', true);
            }

            el.remove();
        },
        options: {
        }
    }
    
    $.widget('ui.bannerForm', BannerForm);

    $(document).ready(function(){
        
    });

})(jQuery);
