<?php

Yii::import('wmdl.web.CApplicableWebModule', true);

/**
 * BannersModule is a combination of back end and front end tools designed to support the following functionality:
 * <ul>
 *   <li>Show banners on front end to site visitors </li>
 *   <li>Track number of impressions </li>
 *   <li>Track number of clicks (for types of banners that support tracking) </li>
 *   <li>Show history stats in tabular format </li>
 * </ul>
 * 
 * The package support custom banners as well as 3rd party ad systems that are integrated via HTML/CSS/JS code snippets. In the initial version only compatibility with Google AdSense is tested; other ad systems are not tested.
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannersModule extends CApplicableWebModule
{
    const BANNER_ROUTE = '/banners/click/redirect';

    /**
     * @var string
     */
    public $defaultController = 'manager';
    /**
     * @var string
     */
    public $author = 'Andrey Kucherenko';
    /**
     * @var string
     */
    public $authorEmail = 'ku4er.prg@gmail.com';
    /**
     * @var string
     */
    public $version = '1.0.0';
    /**
     * @var boolean
     */
    public $isPublic = false;
    /**
     * @var string
     */
    protected $releaseDate = '2011-07-14';

    protected function init()
    {
        parent::init();

        $this->setImport(array(
            'banners.models.*',
            'banners.components.*',
        ));
    }

    public function getName()
    {
        return 'Banners Module';
    }

    public function getDescription()
    {
        return 'This module allows you to manage banner rotation and to track its stats.';
    }

    public function beforeControllerAction($controller, $action)
    {
        if (parent::beforeControllerAction($controller, $action))
        {
            $this->initToolbar();

            return true;
        }
        else
            return false;
    }

    private function initToolbar()
    {
        $toolbar = Yii::app()->getComponent('toolbar');

        if ($toolbar)
        {
            $toolbar->addItem(array(
                'label' => 'Banner Manager',
                'url' => array('/admin/banners/manager/index'),
//                'active' => array('/admin/banners/manager/index'),
                'itemOptions' => array('title' => 'Shows list of banners available on the site and allows content manager to add a new one, edit an existing banner, or delete a banner.')
            ));
            $toolbar->addItem(array(
                'label' => 'Stats',
                'url' => array('/admin/banners/stats/index'),
                'itemOptions' => array('title' => 'Allows the user to view history of banner impressions and clicks grouped by days in tabular format.')
            ));
        }
    }

    public function renderLinkBanner(BannerModel $banner)
    {
        $src = Yii::app()->image->getActiveImageFileUrl($banner, 'image');
        $img = CHtml::image($src, $banner->name);

        echo CHtml::link($img, $this->getBannerUrl($banner), array(
            'target' => 'blank',
        ));
    }

    public function renderHtmlBanner(BannerModel $banner)
    {
        echo $banner->code;
    }

    /**
     * @return string
     */
    public function getBannerUrl(BannerModel $banner)
    {
        return CHtml::normalizeUrl(array(
            self::BANNER_ROUTE,
            'b' => $banner->primaryKey,
        ));
    }

    public function getUsedBannerPk($type)
    {
    	$widgets = WidgetModel::model()->findAll(array(
                'select' => 'params',
                'condition' => 'type = :type',
                'params' => array(
                    ':type' => $type,
    	),
    	));
    	$rels   = CHtml::listData($widgets, 'primaryKey', 'params.banners');
    	$usages = array();
    
    	foreach ($rels as $banners)
    	{
    		if (!is_array($banners))
    		{
    			continue;
    		}
    
    		foreach ($banners as $pk)
    		{
    			$usages[] = $pk;
    		}
    	}
    
    	return array_unique($usages);
    }
}
