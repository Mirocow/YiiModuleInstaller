<?php

CDataGridForm::$defaultValue = 'N/A';

$this->widget('wmdl.components.datagrid.CDataGrid', array(
    'id' => $this->gridId,
    'modelClass' => 'BannerStatsAggregateModel',
    'toolbar' => array(
    	array(
    		'label' => 'Clear',
    		'type' => 'link',
    		'command' => 'clearStats',
    		'htmlOptions' => array('class' => 'button js-custom-clearstats'),
    	)
    ),
//    'form' => array(
//        'defaultValue' => 'N/A',
//    ),
));
?>

<script type="text/javascript">
<!--
$('.js-custom-clearstats').click(function(e){
	if (!confirm('Are you sure you want to clear all stats?')){
		e.preventDefault();
	}
});
//-->
</script>