<p>In order to have the banner displayed in front end, it must be included in a widget.</p>

<script type="html/template" id="WidgetBinding">
<tr>
<td nowrap="nowrap" class="datagrid-form-labels">
<label for="BannerModel_widgets">Binding Management</label>
</td>
<td class="datagrid-form-inputs created widgets">
<div style="text-align: left;">
    <input type="hidden" name="BannerModel[widgets][]" value="0" />
<?php $this->widget('banners.widgets.WidgetCheckBoxList', array(
    'name' => 'BannerModel[widgets][]',
    'value' => $model->widgets,
)); ?>
</div>
</td>
</tr>
</script>
