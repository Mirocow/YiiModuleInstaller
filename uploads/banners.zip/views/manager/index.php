<?php

CDataGridForm::$defaultValue = 'N/A';

$this->widget('wmdl.components.datagrid.CDataGrid', array(
    'id' => $this->gridId,
    'modelClass' => 'BannerModel',
    'wisiwyg' => null,
    'OnFileUpload' => array(Yii::app()->getComponent('image'), 'processActiveImage'),
    'OnFileDettach' => array(Yii::app()->getComponent('image'), 'removeActiveImage'),
    'OnItemCreated' => array($this, 'beforeRowRender'),
    'OnEndWidget' => array($this, 'afterGridRender'),
    'onSave' => array($this, 'reassignWidgets'),
    'editViewWidget'=>'BannerModelEditView',
));