<p>
    This section allows you to add, edit, or delete banners. 
    Changes are applied immediately once you save banners.  
    In order to show the banners in front end, you have to create 
    a widget of type Banner and choose which banners to show.
</p>