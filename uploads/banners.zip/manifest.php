<?php
return array(
	'title' => 'Banners Module',
	'description' => 'This module allows you to add and manage articles organized into categories.',
);