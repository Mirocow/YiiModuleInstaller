<?php

Yii::import('banners.models.BannerModel', true);

/**
 * BannerListBox represents an ...
 *
 * Description of BannerListBox
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class BannerCheckBoxList extends CWidget
{
    public $name;
    public $value = array();

    public function init()
    {
        parent::init();
    }
    
    public function run()
    {
        $items = $this->fetchBanners();
        
        $this->renderListBox($items);
    }
    
    private function fetchBanners()
    {
        return BannerModel::model()->findAll();
    }
    
    private function renderListBox($banners)
    {
        if ($banners !== array())
        {
            $keys = CHtml::listData($banners, 'primaryKey', 'primaryKey');
            $listData = $keys === array() ? $keys : array_combine($keys, array_map('strval', $banners));
            $list = CHtml::checkBoxList($this->name, $this->value, $listData, array(
                'labelOptions' => array(
                    'style' => 'float: left; display: block; width: 250px; text-align: left;',
                ),
                'style' => 'float: left; margin-right: 5px;',
            ));
        }
        else
        {
            $list = '<i>no banners</i>'.CHtml::hiddenField($this->name.'[]', '');
        }
        echo CHtml::tag('div', array(
            'style' => 'float: left;',
        ), $list);
    }

}
