<?php

Yii::import('wmdl.components.widgetFactory.WidgetModel', true);

/**
 * WidgetCheckBoxList represents an ...
 *
 * Description of WidgetCheckBoxList
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class WidgetCheckBoxList extends CWidget
{
    public $name;
    public $value = array();

    public function init()
    {
        parent::init();
    }
    
    public function run()
    {
        $items = $this->fetchWidgets();
        
        $this->renderListBox($items);
    }
    
    private function fetchWidgets()
    {
        return BannerModel::getWidgetList();
    }
    
    private function renderListBox($banners)
    {
        $keys = CHtml::listData($banners, 'primaryKey', 'primaryKey');
        $listData = $keys === array() ? $keys : array_combine($keys, array_map('strval', $banners));
        if ($listData !== array())
        {
            $list = CHtml::checkBoxList($this->name, $this->value, $listData, array(
                'labelOptions' => array(
                    'style' => 'float: left; display: block; width: 250px; text-align: left;',
                ),
                'style' => 'float: left; margin-right: 5px;',
            ));
        }
        else
        {
            $list = CHtml::tag('span', array(
                'class' => 'empty-checkbox-list-placeholder',
            ), 'no widgets');
        }
        
        echo CHtml::tag('div', array(
            'style' => 'float: left;',
        ), $list);
    }

}
