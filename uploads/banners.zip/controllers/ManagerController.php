<?php

Yii::import('admin.widgets.NotificationWidget');
Yii::import('wmdl.components.datagrid.*');

/**
 * ManagerController represents an ...
 *
 * Description of ManagerController
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class ManagerController extends Controller
{
    
    public $gridId = 'BannerManager';

    public function accessRules()
    {
        return array(
            array('allow',
                'actions' => array('index'),
                'roles' => array(ZDbAuthManager::ROLE_ADMIN, 'root'),
            ),
            array('deny',
                'users' => array('*'),
            ),
        );
    }

    /**
     * @backend-name Banner Manager
     */
    public function actionIndex()
    {
        $this->breadcrumbs = array(
            'Modules' => array('/admin/module'),
            'Banners Module' => array('/admin/banners'),
            'Banner Manager',
        );
        $this->pageTitle = 'Banner Manager';
        $this->render('index');
    }

    public function beforeRowRender($event)
    {
        CPropertyValue::ensureBoolean($event->sender->model->used) && $event->sender->noDelete();
    }

    public function afterGridRender($event)
    {
        $cmd = $event->sender->getCommandName();
        $cs  = Yii::app()->getClientScript();
        $assetsUrl = $this->module->assetsUrl;

        switch ($cmd)
        {
            case CBaseDataGrid::CMD_CREATE:
            case CBaseDataGrid::CMD_EDIT:
                $this->renderPartial('index_form_header', array(
                    'model' => $event->sender->model,
                ));
//                $cs->registerScriptFile($assetsUrl . '/js/manager.form.js')
//                        ->registerScript('form', '$("#' . $this->gridId . '_form").bannerForm('.CJavaScript::encode(array(
//                            'model' => $event->sender->model->attributes,
//                        )).');');
                break;
            
            case null:
                $this->renderPartial('index_grid_header');
                $cs->registerScript('form', 'var form = $("#' . $this->gridId . '_form")' . 
                        '.delegate(".used img", "click", function(event){event.stopPropagation();});' . 
                        '$(".used img").css("cursor", "default");');
                break;
            
            default:
                break;
        }
    }
    
    public function reassignWidgets($event)
    {
        $request = Yii::app()->getRequest();
        $model   = $event->sender->model;
        $data    = $request->getPost(get_class($model));
        
        if (!isset($data['widgets'])) $data['widgets'] = array();
        //if (isset($data['widgets']))
        {
            $model->reassignWidgets($data['widgets']);
        }
    }

}