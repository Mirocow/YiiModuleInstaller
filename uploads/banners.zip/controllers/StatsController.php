<?php

Yii::import('wmdl.components.datagrid.*');

/**
 * StatsController represents an ...
 *
 * Description of StatsController
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class StatsController extends Controller
{
    
    public $gridId = 'BannerStats';

    public function accessRules()
    {
        return array(
            array('allow',
                'actions' => array('index'),
                'roles' => array(ZDbAuthManager::ROLE_ADMIN, 'root'),
            ),
            array('deny',
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * @backend-name Banner Stats
     */
    public function actionIndex()
    {
    	if (isset($_GET['BannerStatsAggregateModel']['command']) && 
    		$_GET['BannerStatsAggregateModel']['command'] == 'clearStats')
    	{
    		BannerStatsModel::clear();
    		$this->redirect('/admin/banners/stats/index');
    	}
    	
        $this->breadcrumbs = array(
            'Modules' => array('/admin/module'),
            'Banners Module' => array('/admin/banners'),
            'Banner Stats',
        );
        $this->pageTitle = 'Banner Stats';
        $this->render('index');
    }

}