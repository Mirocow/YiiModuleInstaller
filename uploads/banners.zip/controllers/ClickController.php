<?php

/**
 * ClickController represents an ...
 *
 * Description of ClickController
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class ClickController extends Controller
{
    public $defaultAction = 'redirect';
    
    /**
     * Set of access rules for this controller.
     * 
     * @return array
     */
    public function accessRules()
    {
        return array(
            array('allow',
                'users' => array('*'),
            ),
        );
    }

    public function actionRedirect()
    {
        $bannerId = (int) Yii::app()->getRequest()->getParam('b', 0);
        $banner   = BannerModel::model()->findByPk($bannerId);
        
        if ($banner === null || $banner->type != BannerType::LINK)
        {
            throw new CHttpException('404', 'Requested page not found.');
        }
        
        $banner->updateAfterClick();
        
        $this->redirect($banner->link);
    }

}
