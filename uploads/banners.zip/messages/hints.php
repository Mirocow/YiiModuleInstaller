<?php

return array(
	'BannerModel_type' => 'Select what type of banner you need',
	'BannerModel_name' => 'Provide name of the banner (for internal purposes only, it is not used in front end).',
	'BannerModel_link' => 'Type in the URL that users will be redirected to if they click on the banner. <br />Applies to Image/Link banners only. If neither http:// nor https:// is specified, the current domain name will be appended to the beginning of the URL.',
	'BannerModel_image' => 'Upload the banner image. Jpeg, gif, and png images are allowed. Applies to Image/Link banners only.',
	'BannerModel_code' => 'Paste here the HTML code for your banner. If it is pure javascript, be sure to wrap it into &lt;script&gt;...&lt;/script&gt; tags. Applies to HTML/JavaScript banners only.',
	'BannerModel_impressions' => 'Indicates how many times the banner was shown.',
	'BannerModel_enabled' => 'Specify if you want this banner to appear in front end.',
);