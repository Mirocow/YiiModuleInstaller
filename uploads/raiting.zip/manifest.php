<?php
return array(
	'title' => 'Rating Module',
	'description' => 'Module for manage users in application.',
	'version' => '0.1.0'
);