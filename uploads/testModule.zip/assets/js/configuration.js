(function ($) {
    
//    $.fn.pollParams = function(prefix, data) {
//        var params = {};
//        
//        this.find(':input[id^="' + prefix + '"]').each(function(i, el){
//            var property = el.name.match(/\[([^\]]+)\](\[\]){0,1}$/ig)[0].replace(/\[([^\]]+)\](\[\]){0,1}$/ig, '$1');
//            if ($(el).is(':visible')) {
//                if (typeof data == 'undefined') {
//                    params[property] = $(el).val();
//                } else if (typeof data[property] !== 'undefined') {
//                    $(el).val(data[property]);
//                } else {
//                    $(el).val('');
//                }
//            } else {
//                
//                var wysiwyg = $(el).next('#' + el.id + '_parent');
//                
//                if (wysiwyg.hasClass('mceEditor') && (typeof tinyMCE != 'undefined')) {
//                    if (typeof data == 'undefined') {
//                        params[property] = tinyMCE.get(el.id).getContent();
//                    } else if (typeof data[property] !== 'undefined') {
//                        $(el).val(data[property]);
//                        tinyMCE.get(el.id).setContent(data[property] ? data[property] : '');
//                    } else {
//                        $(el).val('');
//                        tinyMCE.get(el.id).setContent('');
//                    }
//                }
//            }
//        });
//        
//        return data === {} ? this : $.param(params);
//    }
    
    $.fn.pollConfiguration = function(settings) {
        
        var defaults = {};
        var config = $.extend({}, defaults, settings);
        
        return this.each(function(i, el){
            $(el)
            .undelegate('#' + config.prefix + '_id', 'change')
            .delegate('#' + config.prefix + '_id', 'change', function(event) {
                $.ajax({
                    url: config.url,
                    data: $(event.liveFired).moduleParams(config.prefix),
                    type: 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#AnswerList').answerList('removeItems');
                        for (var i = 0; i < data['answers'].length; i++) {
                            $('#AnswerList').answerList('appendItem', data['answers'][i]);
                        }
                        
                        $(event.liveFired).moduleParams(config.prefix, data)
                    }
                })
            });
        })
    }
    
})(jQuery);