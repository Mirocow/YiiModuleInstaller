<?php

Yii::import('wmdl.web.CApplicableAction', true);
Yii::import('poll.models.PollListModel', true);

/**
 * PollListAction represents an ...
 *
 * Description of PollListAction
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollListAction extends CApplicableAction
{

    public function getName()
    {
        return 'Polls List';
    }

    public function getDescription()
    {
        return 'Render list of active polls.';
    }

    public function run()
    {
        $polls = $this->loadModel()->getPolls();
        $view = count($polls) ? 'poll_list' : 'no_polls';
        $this->render($view, array(
            'polls' => $polls,
        ));
    }
    
    public function loadModel()
    {
        $node = Yii::app()->currentNode;
        return $node->getDataRecord();
    }
    
    public function setup($modelClass = null)
    {
        Yii::app()->controller->nodeModel->dataClass = 'PollListModel';
        return null;
    }

}
