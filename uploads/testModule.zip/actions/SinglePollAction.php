<?php

Yii::import('wmdl.web.actions.ZFrontendAction', true);

/**
 * SinglePollAction represents an ...
 *
 * Description of SinglePollAction
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class SinglePollAction extends ZFrontendAction
{
    public function getName()
    {
        return 'Single Poll';
    }

    public function getDescription()
    {
        return 'Render page for a single poll.';
    }

    public function run()
    {
        $poll = $this->loadModel();
        if ($poll->isActive == 0)
        {
            $c = $this->controller;
            $c->pageHeader = 'Poll has expired'; 
            $c->renderText('Sorry, the poll you\'re looking for is no longer active.');
            Yii::app()->end();
        }
        $url = $this->controller->currentNode->getPageUrl();
        Yii::app()->getUser()->setReturnUrl($url);
        $this->render('single_poll', array(
            'pageHeader' => $this->controller->currentNode->pageHeader,
            'pollQuestion' => $poll,
        ));
    }

    public function setup($modelClass = null)
    {
        $this->registerConfigurationScripts();

        $config = parent::setup();
        
        return $config;
    }
    
    public function beforeSetup(CEvent $event)
    {
        $model = $event->sender->configModel;
        $node  = $event->sender->nodeModel;
        
        if ($model->hasAttribute('title') && !$model->title)
        {
            $model->title = ($title = $node->pageTitle) ? $title : $node->caption;
        }
        
        return parent::beforeSetup($event);
    }

    private function registerConfigurationScripts()
    {
        Yii::app()->getClientScript()
                ->registerScriptFile(Yii::app()->getModule('poll')->assetsUrl . '/js/configuration.js')
                ->registerScript(__CLASS__, '$("#module-config").pollConfiguration(' . CJavaScript::encode(array(
                    'prefix' => 'PollQuestionModel',
                    'url' => Yii::app()->createUrl('/admin/poll/manage/api'),
                )) . ');');
    }

}
