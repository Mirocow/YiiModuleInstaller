
<?php

$this->widget('poll.widgets.PollQuestionWidget', array(
    'question' => $pollQuestion,
));