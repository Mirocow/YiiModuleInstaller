<?php foreach ($polls as $poll): ?>

<h2><?php echo $poll->title ?></h2>

<?php $this->renderPartial('single_poll', array(
    'pageHeader' => $poll->title,
    'pollQuestion' => $poll,
)); ?>

<hr />

<?php endforeach; ?>

