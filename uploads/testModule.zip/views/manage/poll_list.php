<?php 
$this->widget('wmdl.components.datagrid.CDataGrid', array(
    'id' => 'PollList',
    'modelClass' => 'PollQuestionModel',
    'editViewWidget' => 'poll.components.PollQuestionEditView',
    'OnItemCreated' => array($this, 'checkAssocNode'),
//    'OnEndWidget' => array($this, 'afterGridRender'),
//    'onSave' => array($this, 'reassignRelatedItems'),
));