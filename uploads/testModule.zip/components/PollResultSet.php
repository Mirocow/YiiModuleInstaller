<?php

/**
 * PollResultSet represents an ...
 *
 * Description of PollResultSet
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollResultSet extends CList
{

    private $_total;
    private $_current;
    private $_colors = array(
        '#1874CD', '#8B4726', '#708090',
        '#8B4500', '#0000CD', '#8B6508',
        '#556B2F', '#8B2500', '#00688B',
        '#00688B', '#8B3A3A', '#8B2323',
        '#8B8B00', '#551A8B', '#006400',
        '#8B0000', '#00EE00', '#551A8B',
        '#2F4F4F', '#607B8B', '#104E8B',
        '#458B00', '#00868B', '#236B8E',
    );

    public function __construct($data=null, $readOnly=false)
    {
        parent::__construct($data, $readOnly);

        reset($this->_colors);
    }

    public function add($item)
    {
        if ($item instanceof PollAnswerModel)
        {
            $result = new stdClass();
            $result->id = $item->id;
            $result->text = $item->text;
            $result->color = $this->getNextColor();
            $result->score = $this->calculateScore($item);
            $result->width = $this->calculateWidth($item);

            parent::add($result);
        }
        else
        {
            throw new CExcepton('Incompatible type given.');
        }
    }

    private function calculateWidth($answer)
    {
        $score = $this->calculateScore($answer);
        $total = $this->getTotalResultCount($answer->questionId);
        
        return $score > 0 ? round((100 / $total * $score) / 100, 2) : $score;
    }

    private function calculateScore(PollAnswerModel $answer)
    {
        $question = $answer->questionId;
        $answer = $answer->id;

        if ($this->_current === null)
        {
            $this->_current = array();
            $this->_total = 0;
            $results = Yii::app()->getComponent('db')
                    ->createCommand()
                    ->select('result')
                    ->from('PollResult')
                    ->where('questionId = :q', array(
                        ':q' => $question,
                    ))
                    ->query();

            foreach ($results as $r)
            {
                $result = CJSON::decode($r['result']);
                $this->countResult($result);
            }
        }

        if (!isset($this->_current[$answer]))
        {
            $this->_current[$answer] = 0;
        }

        return $this->_current[$answer];
    }

    private function getTotalResultCount($question)
    {
        if ($this->_total === null)
        {
            $cmd = Yii::app()->getComponent('db')
                    ->createCommand()
                    ->select('COUNT id')
                    ->from('PollResult')
                    ->where('questionId = :q', array(
                ':q' => $question,
                    ));
            $this->_total = $cmd->queryScalar();
        }

        return $this->_total;
    }

    private function countResult($result)
    {
        while ($rid = array_shift($result))
        {
            if (!isset($this->_current[$rid]))
            {
                $this->_current[$rid] = 0;
            }

            $this->_current[$rid] += 1;
        }

        $this->_total ++;
    }

    private function getNextColor()
    {
        if (!($current = current($this->_colors)))
        {
            reset($this->_colors);
        }

        next($this->_colors);
        return $current;
    }

}

