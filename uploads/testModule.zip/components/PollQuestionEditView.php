<?php

/**
 * PollQuestionEditView represents an ...
 *
 * Description of PollQuestionEditView
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollQuestionEditView extends CDataGridEditView
{

    private function answerWidget()
    {         
        return $this->widget('poll.widgets.AnswerListWidget', array(
            'id' => 'AnswerList',
            'model' => $this->getDataGrid()->getModel(),
            'attribute' => 'answers',
        ), true);
    }
    
    private function appendAnswers()
    {
        $model = $this->getDataGrid()->getModel();
        $this->writeRow(
            $this->getDataGrid()->getForm()->labelEx($model, 'answers'),
            CHtml::tag(
                    'td', 
                    array('class' => 'datagrid-form-inputs'), 
                    $this->answerWidget()));
    }

    protected function renderFields()
    {
        parent::renderFields();
        
        $this->appendAnswers();
    }

}
