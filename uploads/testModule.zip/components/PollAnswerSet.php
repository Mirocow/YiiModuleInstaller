<?php

/**
 * PollAnswerSet represents an ...
 *
 * Description of PollAnswerSet
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollAnswerSet extends CList
{
    public function listData()
    {
        return CHtml::listData($this, 'primaryKey', 'text');
    }
}
