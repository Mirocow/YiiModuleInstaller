<?php

Yii::import('wmdl.web.CApplicableWebModule', true);

/**
 * PollModule represents an ...
 *
 * Description of PollModule
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollModule extends CApplicableWebModule implements ISearchableModule
{
    const MSG_CODE_SUCCESS = 'poll_succeed';
    const MSG_CODE_ERRORS = 'poll_error';
    
    /**
     * @var string
     */
    public $defaultController = 'manage';
    /**
     * @var string
     */
    public $author = 'Andrey Kucherenko';
    /**
     * @var string
     */
    public $authorEmail = 'ku4er.prg@gmail.com';
    /**
     * @var string
     */
    public $version = '1.0.0';
    /**
     * @var boolean
     */
    public $isPublic = true;
    /**
     * @var string
     */
    protected $releaseDate = '2011-10-17';

    public function init()
    {
        parent::init();
        
        $this->setImport(array(
            'application.modules.poll.models.*',
            'application.modules.poll.components.*',
            'application.modules.poll.actions.*',
        ));
    }

    public function getName()
    {
        return 'Poll Module';
    }

    public function getDescription()
    {
        return 'This module allows you to easily add polls on site pages. ';
    }

    public function beforeControllerAction($controller, $action)
    {
        if (parent::beforeControllerAction($controller, $action))
        {
            $this->initToolbar();
            $assetsUrl = $this->assetsUrl;
            Yii::app()->getClientScript()
                    ->registerCssFile($assetsUrl.'/css/frontend.css');
            
            return true;
        }
        else
            return false;
    }

    private function initToolbar()
    {
        $toolbar = Yii::app()->getComponent('toolbar');

        if ($toolbar)
        {
            $toolbar->addItem(array(
                'label' => 'Polls',
                'url' => array('/admin/poll/manage/all'),
            ));
        }
    }

    public function setup($model = null)
    {
        return NULL;
    }
    
    public function hasElements(ISiteNode $node)
    {
        return false;
    }
    
    public function getElements(ISiteNode $node)
    {
        return array();
    }
    
    /**
     * @return IPollRespondent
     */
    public function getRespondent()
    {
        $user = Yii::app()->getUser();
        if ($user->getIsGuest())
        {
            return new GuestRespondent();
        }
        else
        {
            return new MemberRespondent();
        }
    }
    
    public function getVotingUrl()
    {
        return Yii::app()->createUrl('poll/frontend/vote');
    }

}

class MemberRespondent implements IPollRespondent
{
    private $_id;
    
    private $_type;

    public function getType()
    {
        if ($this->_type === null)
        {
            $this->_type = 'member';
        }

        return $this->_type;
    }

    public function setType($type)
    {
        $this->_type = $type;
    }
    
    public function getId()
    {
        if ($this->_id === null)
        {
            $this->populateId();
        }

        return $this->_id;
    }

    public function setId($id)
    {
        $this->_id = $id;
    }

    private function populateId()
    {
        $this->_id = 'wmMember_' . Yii::app()->getUser()->getId();
    }

}

class GuestRespondent implements IPollRespondent
{
    private $_id;
    
    private $_type;

    public function getType()
    {
        if ($this->_type === null)
        {
            $this->_type = 'guest';
        }

        return $this->_type;
    }

    public function setType($type)
    {
        $this->_type = $type;
    }
    
    public function getId()
    {
        if ($this->_id === null)
        {
            $this->populateId();
        }

        return $this->_id;
    }

    public function setId($id)
    {
        $this->_id = $id;
    }

    private function populateId()
    {
        $cookies = Yii::app()->getRequest()->cookies;
        $security = Yii::app()->getSecurityManager();
        $cookieId = $security->hashData('poll_cookie');
        $pollCookie = $cookies->itemAt($cookieId);
        $this->_id = 'wmGuest_' . Yii::app()->getSession()->getSessionId();
        if ($pollCookie === null)
        {
            $pollCookie = new CHttpCookie($cookieId, $security->encrypt($this->_id));
        }
        $pollCookie->expire = strtotime('+12 month');
        $pollCookie->path = Yii::app()->createAbsoluteUrl('/');
        $cookies->add($cookieId, $pollCookie);
    }
}

interface IPollRespondent
{
    /**
     * Returns unique identifier of user that can take part in poll.
     * @return mixed
     */
    public function getId();
    /**
     * Returns identifier of respondent group (e.g. common member, twitter account, facebook account, etc.)
     * Groups and related functionality is not defined yet.
     * @return mixed
     */
    public function getType();
}