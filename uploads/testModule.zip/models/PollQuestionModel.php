<?php

/**
 * PollQuestionModel represents an ...
 *
 * Description of PollQuestionModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $id
 * @property integer $guestVote
 * @property integer $isActive
 * @property string $title
 * @property string $startDate
 * @property string $endDate
 * @property integer $maxAnswers
 * @property string $text
 * @property PollAnswerModel[] $answers
 */
class PollQuestionModel extends CActiveRecord implements INodeDataModel
{
    const RELATED_ASWERS = 'answers';
    private $_updateList;
    private $_deleteList;
    private $_assignedAnswers;

    /**
     * Returns the static model of the specified AR class.
     * @return PollQuestionModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'PollQuestion';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('title, startDate, endDate, text, maxAnswers', 'required', 'on' => 'insert,update'),
            array('startDate, endDate, text, maxAnswers', 'required', 'on' => 'insertNode,updateNode'),
            array('startDate, endDate', 'type', 'type' => 'date', 'dateFormat' => 'yyyy-MM-dd'),
            array('endDate', 'validateGreaterDate', 'compareTo' => 'startDate'),
            array('guestVote, isActive', 'numerical', 'integerOnly' => true, 'max' => 1, 'min' => 0),
            array('title', 'length', 'max' => 255),
            array(
                'maxAnswers', 'numerical', 
                'integerOnly' => true, 'min' => 1,
                'tooSmall' => 'Poll question should accept at least one answer.'),
            ///TODO Implement maxAnswers validation
//            array('maxAnswers', 'validateMaxAnswers'),
        );
    }
    
    /**
     * Checks whether attribute value is not greater than number of assigned answers.
     */
    public function validateMaxAnswers($attribute)
    {
        if ($this->$attribute > $this->countAnswers())
        {
            ///TODO Let english-speaking guy to check wording
            $this->addError($attribute, 'Max number of accepted answers should be greater than total number of answers.');
        }
    }
    
    private function countAnswers()
    {
        if ($this->_assignedAnswers === null)
        {
            return $this->getRelated('answerCount');
        }
        
        return count($this->_assignedAnswers);
    }
    
    public function validateGreaterDate($attribute, $params)
    {
        $gtDate = strtotime($this->getAttribute($attribute));
        $ltDate = strtotime($this->getAttribute($params['compareTo']));
        
        if ($gtDate <= $ltDate)
        {
            $this->addError(
                    $attribute, 
                    $this->getAttributeLabel($attribute) . 
                    ' should be greater than ' . 
                    $this->getAttributeLabel($params['compareTo']));
        }
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'answers' => array(self::HAS_MANY, 'PollAnswerModel', 'questionId'),
            'answerCount' => array(self::STAT, 'PollAnswerModel', 'questionId'),
            'owner' => array(
                self::HAS_ONE, 'StructureModel', 'dataPk',
                'on' => 'dataClass = :class',
                'params' => array(
                    ':class' => get_class(),
                ),
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'isActive' => 'isActive',
            'guestVote' => 'Allow Guests to Vote',
            'title' => 'Title',
            'startDate' => 'Start Date',
            'endDate' => 'End Date',
            'maxAnswers' => 'Max Number of Answers',
            'text' => 'Question',
        );
    }

    public function behaviors()
    {
        return array(
            Yii::app()->search->behaviorName => array(
                'class' => Yii::app()->search->behaviorClass,
                'attributes' => array(
                    'title',
                    'text',
                    'answers[].text',
                ),
            ),
        );
    }

    public function fields()
    {
        return array(
            array('id', 'dropDownList', $this->listPollQuestions()), // int(10) unsigned, primary key
            array('guestVote', 'checkbox'), // tinyint(1) unsigned
            array('startDate', 'zii.widgets.jui.CJuiDatePicker', 
                'model' => $this,
                'attribute' => 'startDate',
                'options' => 'js:$.extend({}, $.datepicker.regional[ "" ], {"dateFormat":"yy-mm-dd"})'),
            array('endDate', 'zii.widgets.jui.CJuiDatePicker', 
                'model' => $this,
                'attribute' => 'endDate',
                'options' => 'js:$.extend({}, $.datepicker.regional[ "" ], {"dateFormat":"yy-mm-dd"})'),
            array('text', 'wmdl.components.tinymce.ETinyMce', 
                'model'=>$this, 
                'attribute'=>'text', 
                'skin' => 'narrow',), // text
            array('maxAnswers', 'textField'), // int(10) unsigned
            array('answers', 'poll.widgets.AnswerListWidget',
                'id' => 'AnswerList',
                'model' => $this,
                'attribute' => 'answers',
                'value' => $this->getRelatedAnswers()), 
        );
    }
    
    private function getRelatedAnswers()
    {
        $relationName = self::RELATED_ASWERS;
        $data = Yii::app()->getRequest()->getParam(get_class($this));
        
        if ($data !== null)
        {
            $postData = $data[$relationName];
            $relation = $this->getActiveRelation($relationName);
            $className = $relation->className;
            $relatedRecords = $this->getRelated($relationName);

            $newRelated = $this->populateRelatedRecords($className, $postData);
            $toDelete = array_udiff($relatedRecords, $newRelated, array($this, 'compareRelatedRecords'));
            $toAssign = array_udiff($newRelated, $relatedRecords, array($this, 'compareRelatedRecords'));
            $toUpdate = array_uintersect($newRelated, $relatedRecords, array($this, 'compareRelatedRecords'));

            $valid = $this->validateRecordList($toAssign, $relation->foreignKey);
            $valid = $this->validateRecordList($toUpdate, $relation->foreignKey) && $valid;
            $this->$relationName = $newRelated;
            
            if ($valid !== true)
            {
                $this->addError($relationName, 'Error saving related data.');
            }

            $this->prepareUpdate($toUpdate, $relation);
            $this->prepareUpdate($toAssign, $relation);
            $this->prepareDelete($toDelete, $relation);
            
            $this->onAfterSave = array($this, 'updateRelatedData');
            $this->onBeforeSave = array($this, 'deleteRelatedData');
        }
        
        return $this->$relationName;
    }
    
    public function updateRelatedData($event)
    {
        $list = $this->getUpdateList();
        foreach ($list as $r)
        {
            $relation = $r['relation'];
            if ($relation instanceof CHasOneRelation || $relation instanceof CHasManyRelation)
            {
                $r['model']->setAttribute($relation->foreignKey, $event->sender->primaryKey);
            }
            if (($saved = $r['model']->save()) === false)
            {
                $message = Yii::t('CDataGrid', 'Error {op} related "{relationName}".', array(
                    '{op}' => empty($r['model']->primaryKey) ? 'creating' : 'updating',
                    '{relationName}' => $relation->name,
                ));
                throw new CDbException($message);
            }
        }
    }
    
    public function deleteRelatedData($event)
    {
        $list = $this->getDeleteList();
        foreach ($list as $r)
        {
            if ($r['model']->delete() === false)
            {
                $message = Yii::t('CDataGrid', 'Error deleting related "{relationName}".', array(
                    '{relationName}' => $r['relation']->name,
                ));
                throw new CDbException($message);
            }
        }
    }
    
    private function prepareDelete($models, $relation)
    {
        $records = array();
        foreach ($models as $m)
        {
            $this->getDeleteList()->add(array(
                'model' => $m,
                'relation' => $relation,
            ));
        }
    }
    
    private function prepareUpdate($models, $relation)
    {
        $records = array();
        foreach ($models as $m)
        {
            $this->getUpdateList()->add(array(
                'model' => $m,
                'relation' => $relation,
            ));
        }
    }
    
    private function compareRelatedRecords(CActiveRecord $record1, CActiveRecord $record2)
    {
        if ($record1->primaryKey == $record2->primaryKey)
            return 0;
        else if ($record1->primaryKey > $record2->primaryKey)
            return 1;
        else
            return -1;
    }
    
    private function validateRecordList($records, $excludeFk = null)
    {
        $valid = true;
        foreach ($records as $r)
        {
            $attrs = array_keys($r->attributes);
            $attrs = array_diff($attrs, array($excludeFk));
            $valid = $r->validate($attrs) && $valid;
        }
        return $valid;
    }
    
    private function populateRelatedRecords($className, $data)
    {
        $records = array();
        $producer = CActiveRecord::model($className);
        foreach ($data as $params)
        {
            $records[] = $r = $producer->populateRecord($params, false);
            if (empty($r->primaryKey))
            {
                $r->primaryKey = null;
                $r->isNewRecord = true;
            }
        }
        return $records;
    }

    public function getUpdateList()
    {
        if ($this->_updateList === null)
        {
            $this->_updateList = new CList;
        }

        return $this->_updateList;
    }

    public function getDeleteList()
    {
        if ($this->_deleteList === null)
        {
            $this->_deleteList = new CList;
        }

        return $this->_deleteList;
    }

    private function listPollQuestions()
    {
        $list = array('' => 'Create new poll') + CHtml::listData(self::model()->findAll(), 'id', 'title');
        return $list;
    }
    
    public function getIsAnswered(IPollRespondent $respondent)
    {
        return PollResultModel::model()->exists(array(
            'condition' => 'result.questionId = :q AND result.respondentId = :r',
            'params' => array(
                ':q' => $this->primaryKey,
                ':r' => $respondent->getId(),
            ),
        ));
    }
    
    public function getAnswerSet()
    {
        return new PollAnswerSet($this->answers);
    }
    
    public function getResultSet()
    {
        return new PollResultSet($this->answers);
    }
    
    public function getIsMultipleChoice()
    {
        return $this->maxAnswers > 1;
    }
    
    public function defaultScope()
    {
        return array(
            'alias' => 'question',
        );
    }
    
    public function scopes()
    {
        return array(
            'active' => array(
                'condition' => 'question.isActive = :a',
                'params' => array(':a' => 1),
            ),
        );
    }
    
    public function getIsExpired()
    {
        $ended = strtotime($this->endDate);
        $today = strtotime('now');
        
        return $ended < $today;
    }

    public function getSiteNode()
    {
        return $this->getRelated('owner');
    }
    
    public function getIsPermitted(IPollRespondent $respondent)
    {
        return !($respondent instanceof GuestRespondent && $this->guestVote == 0);
    }

}