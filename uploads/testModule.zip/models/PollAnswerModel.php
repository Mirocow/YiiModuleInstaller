<?php

/**
 * PollAnswerModel represents an ...
 *
 * Description of PollAnswerModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $id
 * @property string $questionId
 * @property string $text
 * @property PollQuestionModel $question
 */
class PollAnswerModel extends CActiveRecord
{

    /**
     * Returns the static model of the specified AR class.
     * @return PollAnswerModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'PollAnswer';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('questionId, text', 'required'),
            array('questionId', 'length', 'max' => 10),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'question' => array(self::BELONGS_TO, 'PollQuestionModel', 'questionId'),
            'owner' => array(
                self::HAS_ONE, 'StructureModel', 'dataPk',
                'on' => 'dataClass = :class',
                'params' => array(
                    ':class' => get_class(),
                ),
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'questionId' => 'Question',
            'text' => 'Text',
        );
    }

//    public function behaviors()
//    {
//        return array(
//            Yii::app()->search->behaviorName => array(
//                'class' => Yii::app()->search->behaviorClass,
//                'attributes' => array(
//                    'text',
//                ),
//            ),
//        );
//    }

}