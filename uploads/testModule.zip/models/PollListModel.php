<?php

/**
 * PollListModel represents a facade beside module data.
 * It provides search operation on data items.
 */
class PollListModel extends CModel implements INodeDataModel
{
    public function attributeNames()
    {
        return array();
    }
    
    public function behaviors()
    {
        return array(
            Yii::app()->search->behaviorName => array(
                'class' => Yii::app()->search->behaviorClass,
                'attributes' => array(
                    'polls[].title',
                    'polls[].text',
                    'polls[].answers[].text',
                ),
            ),
        );
    }
    
    public function getPolls()
    {
        return PollQuestionModel::model()->active()->findAll();
    }
    
    public function getSiteNode()
    {
        return $this->getRelated('owner');
    }
    
    public function getPrimaryKey()
    {
        return 0;
    }

}