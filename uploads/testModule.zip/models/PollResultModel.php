<?php

/**
 * PollResultModel represents an ...
 *
 * Description of PollResultModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $id
 * @property string $questionId
 * @property string $respondentId
 * @property string $result
 * @property PollRespondentModel $respondent
 * @property PollQuestionModel $question
 */
class PollResultModel extends CActiveRecord
{

    /**
     * Returns the static model of the specified AR class.
     * @return PollResultModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'PollResult';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('questionId, respondentId, result', 'required'),
            array(
                'questionId', 'exist', 
                'attributeName' => 'id', 
                'className' => 'PollQuestionModel',
                'criteria' => array(
                    'condition' => 'question.isActive=1'
                ),
            ),
            array('result', 'type', 'type' => 'array'),
            array('result', 'validateResultLength'),
            array('questionId', 'filter', 'filter' => 'intval'),
            array('respondentId', 'length', 'min' => 1, 'max' => 255),
            array('respondentId', 'validatePermission'),
        );
    }
    
    public function validatePermission($attr)
    {
        $respondent = Yii::app()->getModule('poll')->getRespondent();
        $question = $this->getRelated('question', true);
        if ($question->getIsPermitted($respondent) == false)
        {
            $this->addError($attr, 'You\'re not permitted to take part in this poll.');
        }
    }
    
    public function validateResultLength($attribute)
    {
        
        if (!$this->hasErrors($attribute) && !$this->hasErrors('questionId'))
        {
            $result = $this->getAttribute($attribute);
            $question = $this->getRelated('question', true);
            
            if ($question === null)
            {
                $this->addError($attribute, 'Cannot assign result to unkown question.');
            }
            else if (count($result) > $question->maxAnswers)
            {
                $m = sprintf(
                        'Too much answers submitted. This poll accept only %d %s.',
                        $question->maxAnswers,
                        $question->getIsMultipleChoice() ? 'answers' : 'answer');
                $this->addError($attribute, $m);
            }
        }
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'respondent' => array(self::BELONGS_TO, 'PollRespondentModel', 'respondentId'),
            'question' => array(self::BELONGS_TO, 'PollQuestionModel', 'questionId'),
            'owner' => array(
                self::HAS_ONE, 'StructureModel', 'dataPk',
                'on' => 'dataClass = :class',
                'params' => array(
                    ':class' => get_class(),
                ),
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'questionId' => 'Question',
            'respondentId' => 'Respondent',
            'result' => 'Result',
        );
    }
    
    protected function beforeSave()
    {
        $this->serializeResults();
        return parent::beforeSave();
    }
    
    protected function afterConstruct()
    {
        $this->unserializeResults();
        return parent::afterConstruct();
    }
    
    protected function afterFind()
    {
        $this->unserializeResults();
        return parent::afterFind();
    }
    
    protected function afterSave()
    {
        $this->unserializeResults();
        return parent::afterSave();
    }
    
    private function serializeResults()
    {
        if ($this->result === null)
        {
            $this->result = array();
        }
        
        if (is_array($this->result))
        {
            $this->result = CJSON::encode($this->result);
        }
    }
    
    private function unserializeResults()
    {
        if (is_array($this->result) === false)
        {
            $this->result = CJSON::decode($this->result);
        }
    }
    
    public function defaultScope()
    {
        return array(
            'alias' => 'result',
        );
    }

}