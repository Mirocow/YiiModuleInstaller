<?php

/**
 * PollRespondentModel represents an ...
 *
 * Description of PollRespondentModel
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 * @property string $id
 * @property integer $type
 * @property string $joined
 * @property PollAnswerModel[] $answers
 * @deprecated
 */
class PollRespondentModel extends CActiveRecord
{

    /**
     * Returns the static model of the specified AR class.
     * @return PollRespondentModel the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName()
    {
        return 'PollRespondent';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules()
    {
        return array(
            array('joined', 'required'),
            array('type', 'numerical', 'integerOnly' => true),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations()
    {
        return array(
            'answers' => array(self::HAS_MANY, 'PollAnswerModel', 'respondentId'),
            'owner' => array(
                self::HAS_ONE, 'StructureModel', 'dataPk',
                'on' => 'dataClass = :class',
                'params' => array(
                    ':class' => get_class(),
                ),
            ),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID',
            'type' => 'Type',
            'joined' => 'Joined',
        );
    }

}