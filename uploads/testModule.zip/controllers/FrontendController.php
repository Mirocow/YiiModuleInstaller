<?php

Yii::import('poll.actions.*');

/**
 * FrontendController represents an ...
 *
 * Description of FrontendController
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class FrontendController extends Controller
{
    const SINGLE_POLL_ACTION = 'single';
    const POLL_LIST_ACTION = 'list';

    private function loadPoll()
    {
        $pollId = (int) Yii::app()->getRequest()->getParam('poll');
        $question = PollQuestionModel::model()->findByPk($pollId);
        if ($question === null)
        {
            throw new CHttpException(404, 'Requested poll not found.');
        }
        return $question;
    }

    private function loadResultData()
    {
        return Yii::app()->getRequest()->getParam('answer');
    }
    
    public function actions()
    {
        return array(
            self::SINGLE_POLL_ACTION => array(
                'class' => 'SinglePollAction',
                'modelClass' => 'PollQuestionModel',
            ),
            self::POLL_LIST_ACTION => array(
                'class' => 'PollListAction',
//                'modelClass' => 'PollGroupModel',
            ),
        );
    }

    public function actionVote()
    {
        $request = Yii::app()->getRequest();
        $user = Yii::app()->getUser();
        $returnUrl = $request->getParam('returnUrl');
        if (ZPropertyValue::ensureValue($returnUrl) === null)
        {
            $returnUrl = $user->getReturnUrl();
        }
        else
        {
            $returnUrl = urldecode($returnUrl);
        }
        $form = new PollResultModel;
        $data = $form->attributes = $request->getParam('Poll', array());
        
        if ($data === array())
        {
            $user->setFlash(PollModule::MSG_CODE_ERRORS, 'No data submitted.');
        }
        else if ($form->validate())
        {
            if ($form->save())
            {
                $user->setFlash(PollModule::MSG_CODE_SUCCESS, 'Your vote is counted.');
            }
            else
            {
                // this message should never appear
                $user->setFlash(PollModule::MSG_CODE_ERRORS, 'Something went wrong, we can not save your result.');
            }
        }
        else
        {
            $user->setFlash(PollModule::MSG_CODE_ERRORS, CHtml::errorSummary($form));
        }
        
        $this->redirect($returnUrl);
    }
}
