<?php

/**
 * ManageController represents an ...
 *
 * Description of ManageController
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class ManageController extends Controller
{
    public $defaultAction = 'all';

    public function accessRules()
    {
        return array(
            array('allow',
                'roles' => array(ZDbAuthManager::ROLE_ADMIN, 'root'),
            ),
            array('deny',
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * @backend-name Poll list
     * @backend-description Management Polls 
     */
    public function actionAll()
    {
        $this->render('poll_list');
    }
    
    public function actionApi()
    {
        $id = (int) Yii::app()->getRequest()->getParam('id');
        $poll = PollQuestionModel::model()->findByPk($id);
        
        if ($poll === null)
        {
            $poll = new PollQuestionModel;
        }
        
        $data = array_merge($poll->attributes,
                array('answers' => array_values(CHtml::listData($poll->answers, 'id', 'attributes'))));
        
        echo CJSON::encode($data);
    }
    
    public function checkAssocNode($event)
    {
        if ($event->sender->model->owner)
        {
            $event->sender->noDelete();
        }
    }
    
}
