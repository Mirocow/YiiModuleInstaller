<?php
return array(
	'title' => 'Test Module',
	'description' => 'This module allows you to add and manage articles organized into categories.',
);