<?php

/**
 * AnswerListWidget represents an ...
 *
 * Description of AnswerListWidget
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class AnswerListWidget extends CInputWidget
{
    
    private $_assetsUrl;

    public function init()
    {
        parent::init();

        $attribute = $this->attribute;
        $this->value = $this->model->$attribute;

        $this->htmlOptions = array_merge($this->htmlOptions, array(
            'id' => $this->getId()));
        
        if (!isset($this->htmlOptions['class']))
        {
            $this->htmlOptions['class'] = '';
        }
        
        $this->htmlOptions['class'] .= ' answer-list';
        
        $this->registerClientScript();
    }
    
    public function getAssetsUrl()
    {
        if ($this->_assetsUrl === null)
        {
            $this->_assetsUrl = Yii::app()
                    ->getAssetManager()
                    ->publish(dirname(__FILE__).'/assets', 
                            false, -1, YII_DEBUG) . '/' . __CLASS__;
        }

        return $this->_assetsUrl;
    }

    private function registerClientScript()
    {
        $assetsUrl = $this->getAssetsUrl();
        list($inputName, $inputId) = $this->resolveNameID();
        
        if (Yii::app()->getRequest()->getIsAjaxRequest())
        {
            echo CHtml::cssFile($assetsUrl.'/styles.css');
            echo CHtml::scriptFile($assetsUrl.'/script.js');
        }
        
        Yii::app()->getClientScript()
                ->registerCoreScript('jquery')
                ->registerCssFile($assetsUrl.'/styles.css')
                ->registerScriptFile($assetsUrl.'/script.js')
                ->registerScript(__CLASS__, '$("#'.$this->getId().'").answerList('.CJavaScript::encode(array(
                    'template' => $this->render('answer_list/single_item', array(
                        'name' => $inputName.'[{{i}}]',
                        'id' => $inputId.'_{{i}}',
                        'text' => '',
                        'recordId' => '',
                    ), true)
                )).');');
    }
    
    public function run()
    {
        list($inputName, $inputId) = $this->resolveNameID();

        $this->render('answer_list/full_list', array(
            'htmlOptions' => array_merge($this->htmlOptions, array(
                'id' => $this->getId(),
            )),
            'answers' => $this->value,
            'inputName' => $inputName,
            'inputId' => $inputId,
        ));
    }

}
