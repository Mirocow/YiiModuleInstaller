<div class="js-answer answer-item">
    <input type="text" name="<?php echo $name ?>[text]" id="<?php echo $id ?>_text" value="<?php echo $text ?>" />
    <input type="hidden" name="<?php echo $name ?>[id]" id="<?php echo $id ?>_id" value="<?php echo $recordId ?>" />
    <a href="#" class="js-answer-delete answer-item-delete" data-record-id="<?php echo $recordId ?>">
        #
    </a>
    <div style="clear:both"></div>
    <?php isset($errorSummary) && print($errorSummary) ?>
</div>