<?php echo CHtml::openTag('div', $htmlOptions); ?>

<div class="js-answer-list">

<?php foreach ($answers as $i => $answer): ?>

<?php $this->render('answer_list/single_item', array(
    'name' => $inputName.'['.$i.']',
    'id' => $inputId.'_'.$i,
    'text' => $answer->text,
    'recordId' => $answer->id,
    'errorSummary' => CHtml::errorSummary($answer, ''),
)); ?>

<?php endforeach; ?>

</div>

<div class="js-new-answer answer-new-item">
    <a href="#" class="js-answer-add answer-item-add">
        add one more answer
    </a>
</div>

<?php echo CHtml::closeTag('div'); ?>
