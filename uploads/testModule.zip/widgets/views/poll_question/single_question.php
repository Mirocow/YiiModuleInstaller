<p><?php echo $question ?></p>
