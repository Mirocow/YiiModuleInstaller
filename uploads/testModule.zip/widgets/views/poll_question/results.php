<?php $css = ''; ?>
<?php foreach ($resultSet as $result): ?>
<?php 
$class = 'poll-result-' . $result->id;
$width = round($result->width * 100);
$width = $width ? $width : 1; 
$css .= '.'.$class." { background-color:{$result->color}; width: {$width}%; }\n";
?>
<dl class="poll-results clearfix">
    <dt class="poll-answer">
        <?php echo sprintf('%s scored %d %s', $result->text, $result->score, $result->score == 1 ? 'vote' : 'votes'); ?>
    </dt>
    <dd>
        <div class="poll-result poll-result-<?php echo $result->id ?>">
            <?php echo $result->text ?>
        </div>
    </dd>
    </dl>
</dl>
<?php endforeach; ?>
<?php Yii::app()->getClientScript()->registerCss('poll-results-'.$this->getId(), $css); ?>