<?php if ($user->hasFlash(PollModule::MSG_CODE_ERRORS)): ?>
<div class="errors error_summary">
    <?php echo $user->getFlash(PollModule::MSG_CODE_ERRORS); ?>
</div>
<?php endif; ?>

<?php if ($user->hasFlash(PollModule::MSG_CODE_SUCCESS)): ?>
<div class="vote-succeedquestionId">
    <?php echo $user->getFlash(PollModule::MSG_CODE_SUCCESS); ?>
</div>
<?php endif; ?>


<form action="<?php echo $votingUrl ?>" method="POST">
    
    <div class="poll-answers">
        <?php echo call_user_func(
                $renderFunction, 
                'Poll[result][]', 
                $selectedElements, 
                $answerSet->listData()) ?>
    </div>
    
    <div class="poll-submit">
        <?php echo CHtml::hiddenField('Poll[questionId]', $pollId); ?>
        <?php echo CHtml::hiddenField('Poll[respondentId]', $respondentId); ?>
        <?php echo CHtml::hiddenField('returnUrl', $returnUrl); ?>
        <?php echo CHtml::submitButton('Vote'); ?>
    </div>
    
</form>