<?php

/**
 * PollQuestionWidget represents an ...
 *
 * Description of PollQuestionWidget
 *
 * @author Andrey Kucherenko <ku4er.prg@gmail.com>
 * @link http://www.bluefountainmedia.com/
 */
class PollQuestionWidget extends CWidget
{
    const QUESTION_VIEW = 'single_question';
    const ANSWERS_VIEW = 'unanswered';
    const RESULT_VIEW = 'results';
    /**
     * @var PollQuestionModel
     */
    public $question;

    /**
     * @var string
     */
    public $viewsGroup = 'poll_question';
    
    private $_respondent;

    public function init()
    {
        parent::init();
    }

    public function run()
    {
        $this->renderQuestion();
        $this->renderAnswerForm();
    }

    private function renderQuestion()
    {
        $this->render($this->viewsGroup . '/' . self::QUESTION_VIEW, array(
            'question' => $this->question->text,
        ));
    }

    private function renderAnswerForm()
    {
        $question = $this->question;
        $respondent = $this->getRespondent();
        if ($question->getIsAnswered($respondent) || $question->getIsExpired() || !$question->getIsPermitted($respondent))
        {
            $this->render($this->viewsGroup . '/' . self::RESULT_VIEW, array(
                'resultSet' => $question->getResultSet(),
            ));
        }
        else
        {
        	$returnUrl = (null !== ($node = Yii::app()->getComponent('sitemap')->getCurrentNode()))
        		? urlencode($node->getPageUrl()) : Yii::app()->getRequest()->getRequestUri();
            $this->render($this->viewsGroup . '/' . self::ANSWERS_VIEW, array(
                'renderFunction' => array('CHtml', $question->getIsMultipleChoice() ? 'checkboxList' : 'radioButtonList'),
                'selectedElements' => $question->getIsMultipleChoice() ? array() : null,
                'answerSet' => $question->getAnswerSet(),
                'votingUrl' => Yii::app()->getModule('poll')->getVotingUrl(),
                'pollId' => $question->primaryKey,
                'respondentId' => $respondent->getId(),
                'user' => Yii::app()->getUser(),
                'returnUrl' => $returnUrl,
            ));
        }
    }
    
    /**
     * @return IPollRespondent
     */
    public function getRespondent()
    {
        if ($this->_respondent === null)
        {
            $this->_respondent = Yii::app()->getModule('poll')->getRespondent();
        }

        return $this->_respondent;
    }

}
