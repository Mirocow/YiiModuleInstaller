/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * JS-script file
 * Author: A.Kucherenko <ku4er.prg@gmail.com>
 * Package: 
 **/

(function($){

    $.fn.answerList = function(method) {

        var element = this;
        var methods = {

            init : function(options) {
                return this.each(function() {
                    var $element = $(this), element = this; 
                    $element.data('settings', $.extend({}, $.fn.answerList.defaults, options));
                    
                    $element.delegate('.js-answer-delete', 'click', function(event) {
                        event.preventDefault();
                        $element.answerList('deleteItem', $(this).parents('.js-answer'));
                    }).delegate('.js-answer-add', 'click', function(event) {
                        event.preventDefault();
                        $element.answerList('addItem');
                    });
                });

            },

            addItem: function() {
                var newIndex = element.find('.js-answer-list').children('.js-answer').length;
                var settings = element.data('settings');
                var input = $(settings.template.replace(/\{\{i\}\}/g, newIndex));
                input.hide();
                element.find('.js-answer-list').append(input);
                input.slideDown(400);
            },

            deleteItem: function(item) {
                item.slideUp(400, function (){
                    item.remove();
                });
            },

            removeItems: function() {
                element.find('.js-answer').remove();
            },

            appendItem: function(params) {
                element.answerList('addItem');
                var item = element.find('.js-answer-list').children('.js-answer').last();
                item.find('input[type=text]').val(params.text);
                item.find('input[type=hidden]').val(params.id);
            },

            // a public method. for demonstration purposes only - remove it!
            foo_public_method: function() {
                // code goes here
            }

        }

        var helpers = {
            foo_private_method: function() {
                // code goes here
            }
        }

        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error( 'Method "' +  method + '" does not exist in answerList plugin!');
        }

    }

    $.fn.answerList.defaults = {
//        foo: 'bar'
    };

    $.fn.answerList.settings = {};

})(jQuery);
